package com.example.myfirstproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button1;
    Button button2;
    TextView title_text;
    TextView title_text2;
    EditText show_text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void changeColour(View view){
        button1=findViewById(R.id.red_button);
        button1.setBackgroundColor(0XFF20E119);
        title_text=findViewById(R.id.textView);
        title_text.setText("Welcome to the Android Class\n");
        show_text=findViewById(R.id.input_text);
        String input=show_text.getText().toString();
        title_text.setText(input);

    }
    public void changeColour2(View view){
        button2=findViewById(R.id.oran_button);
        button2.setBackgroundColor(0xFFBB86FC);
        title_text2=findViewById(R.id.textView);
        title_text2.setText("Welcome to the Programming Class\n");
    }
}